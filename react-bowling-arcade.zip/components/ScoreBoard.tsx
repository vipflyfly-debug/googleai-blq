import React from 'react';
import { FrameResult } from '../types';
import { MAX_FRAMES } from '../constants';

interface ScoreBoardProps {
  frames: FrameResult[];
  currentFrameIndex: number;
}

const ScoreBoard: React.FC<ScoreBoardProps> = ({ frames, currentFrameIndex }) => {
  // Fix: Handle null frames safely using optional chaining and fallback
  const totalScore = frames.reduce((sum, f) => sum + (f?.score || 0), 0);

  return (
    <div className="w-full max-w-[400px] bg-slate-800 rounded-lg p-4 mb-4 shadow-lg border border-slate-700">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-xl font-bold text-amber-400">Scoreboard</h2>
        <div className="text-2xl font-bold text-white">Total: {totalScore}</div>
      </div>
      
      <div className="grid grid-cols-3 gap-2">
        {Array.from({ length: MAX_FRAMES }).map((_, idx) => {
          const frame = frames[idx];
          const isActive = idx === currentFrameIndex;
          
          return (
            <div 
              key={idx} 
              className={`flex flex-col items-center p-2 rounded ${
                isActive ? 'bg-amber-900/40 border border-amber-500' : 'bg-slate-700'
              }`}
            >
              <span className="text-xs text-slate-400 uppercase font-bold">Frame {idx + 1}</span>
              <div className="flex gap-2 mt-1 text-sm font-mono">
                <span className="w-6 h-6 flex items-center justify-center bg-slate-900 rounded">
                  {frame ? frame.throw1 : '-'}
                </span>
                <span className="w-6 h-6 flex items-center justify-center bg-slate-900 rounded">
                  {frame ? (frame.throw1 === 10 ? '-' : frame.throw2) : '-'}
                </span>
              </div>
              <div className="mt-1 font-bold text-lg text-amber-200">
                {frame ? frame.score : 0}
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="mt-2 text-xs text-slate-500 text-center">
        *Bonus: Clear all 10 pins in a frame for +2 points!
      </div>
    </div>
  );
};

export default ScoreBoard;