import React, { useState, useEffect, useRef } from 'react';
import { GamePhase } from '../types';
import { Target, ArrowUp, Zap } from 'lucide-react';

interface GameControlsProps {
  phase: GamePhase;
  onPositionChange: (xPercent: number) => void;
  onConfirmAim: () => void;
  onThrow: (power: number, angleOffset: number) => void;
}

type ControlStep = 'SET_ANGLE' | 'SET_POWER';

const GameControls: React.FC<GameControlsProps> = ({ 
  phase, 
  onPositionChange, 
  onConfirmAim, 
  onThrow 
}) => {
  const [positionVal, setPositionVal] = useState(50);
  
  // Internal state for the two-step throw process
  const [controlStep, setControlStep] = useState<ControlStep>('SET_ANGLE');
  const [lockedAngle, setLockedAngle] = useState<number>(0);
  
  // Animation values
  const [angleVal, setAngleVal] = useState(0); // -30 to 30 degrees
  const [powerVal, setPowerVal] = useState(0); // 0 to 100 percent

  const requestRef = useRef<number>(0);
  const timeRef = useRef<number>(0);

  // Reset internal steps when entering the phase
  useEffect(() => {
    if (phase === GamePhase.POWER_ANGLE) {
      setControlStep('SET_ANGLE');
      setAngleVal(0);
      setPowerVal(0);
      setLockedAngle(0);
      timeRef.current = 0;
    }
  }, [phase]);

  // Handle Aiming (Position)
  useEffect(() => {
    if (phase === GamePhase.AIMING) {
      onPositionChange(positionVal);
    }
  }, [positionVal, phase, onPositionChange]);

  // Animation Loop
  useEffect(() => {
    if (phase !== GamePhase.POWER_ANGLE) {
      cancelAnimationFrame(requestRef.current);
      return;
    }

    const animate = (time: number) => {
      // Use time to drive smooth sine waves
      // Angle: Slow oscillation (-30 to 30)
      if (controlStep === 'SET_ANGLE') {
        const speed = 0.001; // Slower speed (was 0.002)
        const angle = Math.sin(time * speed) * 35; // +/- 35 degrees max
        setAngleVal(angle);
      } 
      // Power: Faster oscillation (0 to 100)
      else if (controlStep === 'SET_POWER') {
        const speed = 0.002; // Slower speed (was 0.005)
        // 0 to 1 sin wave
        const raw = (Math.sin(time * speed) + 1) / 2;
        setPowerVal(raw * 100);
      }

      requestRef.current = requestAnimationFrame(animate);
    };

    requestRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(requestRef.current);
  }, [phase, controlStep]);

  const handleLockAngle = () => {
    setLockedAngle(angleVal);
    setControlStep('SET_POWER');
  };

  const handleFinalThrow = () => {
    // Map powerVal (0-100) to physics power (approx 10-18)
    // Min power 10 to ensure it reaches pins
    const physicsPower = 10 + (powerVal / 100) * 10; 
    onThrow(physicsPower, lockedAngle);
  };

  // --- RENDER ---

  if (phase === GamePhase.AIMING) {
    return (
      <div className="w-full max-w-[400px] bg-slate-800 p-4 rounded-t-lg border-t border-slate-700 animate-slide-up shadow-[0_-4px_20px_rgba(0,0,0,0.3)]">
        <div className="flex items-center gap-2 mb-3 text-amber-400">
          <Target size={20} />
          <span className="font-bold text-lg">Step 1: Position</span>
        </div>
        
        <div className="relative mb-6 pt-2">
            <input
            type="range"
            min="10"
            max="90"
            value={positionVal}
            onChange={(e) => setPositionVal(parseInt(e.target.value))}
            className="w-full h-4 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500 hover:accent-amber-400"
            />
            <div className="flex justify-between text-xs text-slate-500 mt-2 px-1">
                <span>Left</span>
                <span>Center</span>
                <span>Right</span>
            </div>
        </div>

        <button
          onClick={onConfirmAim}
          className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg transition-colors flex justify-center items-center gap-2 shadow-lg active:scale-95 transform"
        >
          Confirm Position
        </button>
      </div>
    );
  }

  if (phase === GamePhase.POWER_ANGLE) {
    return (
      <div className="w-full max-w-[400px] bg-slate-800 p-5 rounded-t-lg border-t border-slate-700 shadow-[0_-4px_20px_rgba(0,0,0,0.3)]">
        
        {controlStep === 'SET_ANGLE' && (
          <div className="animate-fade-in">
             <div className="flex items-center gap-2 mb-4 text-sky-400">
              <ArrowUp size={20} />
              <span className="font-bold text-lg">Step 2: Set Direction</span>
            </div>

            {/* Angle Visualizer */}
            <div className="relative h-32 bg-slate-900 rounded-lg mb-4 overflow-hidden border border-slate-600 flex justify-center items-end pb-4">
               {/* Reference Grid */}
               <div className="absolute top-0 bottom-0 left-1/2 w-0.5 bg-slate-700/50"></div>
               <div className="absolute bottom-0 w-full h-px bg-slate-700"></div>

               {/* Rotating Arrow */}
               <div 
                 className="origin-bottom transition-transform duration-75 will-change-transform"
                 style={{ 
                    transform: `rotate(${angleVal}deg)`,
                    height: '80px' 
                 }}
               >
                  <div className="w-1.5 h-full bg-sky-500 rounded-t-full shadow-[0_0_10px_rgba(14,165,233,0.6)] relative">
                      <div className="absolute -top-3 -left-[5px] w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-b-[12px] border-b-sky-500"></div>
                  </div>
               </div>
               
               {/* Angle Value Display */}
               <div className="absolute top-2 right-2 text-xs font-mono text-sky-400">
                  {Math.round(angleVal)}°
               </div>
            </div>

            <button
              onClick={handleLockAngle}
              className="w-full py-4 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-lg transition-colors text-xl shadow-lg active:scale-95 transform"
            >
              LOCK DIRECTION
            </button>
            <p className="text-center text-slate-500 text-xs mt-2">Click to lock the angle</p>
          </div>
        )}

        {controlStep === 'SET_POWER' && (
           <div className="animate-fade-in">
            <div className="flex items-center gap-2 mb-4 text-red-400">
              <Zap size={20} />
              <span className="font-bold text-lg">Step 3: Set Power</span>
            </div>

            <div className="flex gap-4 mb-4">
                {/* Visual Feedback of locked angle */}
                <div className="w-1/3 bg-slate-900 rounded border border-slate-700 flex flex-col items-center justify-center p-2 opacity-50">
                    <span className="text-xs text-slate-400 mb-1">Angle</span>
                    <ArrowUp 
                        size={32} 
                        className="text-sky-500" 
                        style={{ transform: `rotate(${lockedAngle}deg)` }} 
                    />
                </div>

                {/* Power Bar */}
                <div className="flex-1 h-24 bg-slate-900 rounded border border-slate-600 relative overflow-hidden">
                    <div 
                        className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-green-500 via-yellow-500 to-red-600 transition-all duration-75 ease-linear"
                        style={{ height: `${powerVal}%` }}
                    ></div>
                    
                    {/* Tick Marks */}
                    <div className="absolute top-[25%] left-0 right-0 h-px bg-black/20"></div>
                    <div className="absolute top-[50%] left-0 right-0 h-px bg-black/20"></div>
                    <div className="absolute top-[75%] left-0 right-0 h-px bg-black/20"></div>

                    <div className="absolute top-2 left-2 text-white font-bold drop-shadow-md text-xl">
                        {Math.round(powerVal)}%
                    </div>
                </div>
            </div>

            <button
              onClick={handleFinalThrow}
              className="w-full py-4 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg transition-colors text-xl shadow-lg active:scale-95 transform"
            >
              THROW BALL!
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="w-full h-16 flex items-center justify-center text-slate-500 italic bg-slate-800/20 rounded">
      {phase === GamePhase.ROLLING ? "Ball rolling..." : "Next turn ready..."}
    </div>
  );
};

export default GameControls;