import React, { useRef, useEffect } from 'react';
import { GamePhase, PinEntity } from '../types';
import { 
  CANVAS_WIDTH, 
  CANVAS_HEIGHT, 
  LANE_COLOR, 
  GUTTER_COLOR, 
  BALL_RADIUS, 
  PIN_RADIUS, 
  PIN_START_Y, 
  PIN_SPACING_X, 
  PIN_SPACING_Y,
  FRICTION,
  BOUNCE_FACTOR,
  PLAY_AREA_MIN_X,
  PLAY_AREA_MAX_X
} from '../constants';

interface BowlingLaneProps {
  phase: GamePhase;
  ballStartXPercent: number;
  throwParams: { power: number; angle: number } | null;
  onRollingComplete: (pinsDown: number[]) => void;
  resetTrigger: number;
}

const BALL_MASS = 5.0;
const PIN_MASS = 1.0;
const RESTITUTION = 0.6; // Bounciness for balls/pins

const BowlingLane: React.FC<BowlingLaneProps> = ({
  phase,
  ballStartXPercent,
  throwParams,
  onRollingComplete,
  resetTrigger
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Mutable game state
  // Initialize useRef with 0 to fix "Expected 1 arguments" error on some setups.
  const gameState = useRef({
    ball: { x: CANVAS_WIDTH / 2, y: CANVAS_HEIGHT - 60, vx: 0, vy: 0 },
    pins: [] as PinEntity[],
    isRolling: false,
    stoppedFrames: 0
  });

  const requestRef = useRef<number>(0);

  // --- Initialization Helper ---
  const initPins = () => {
    const pins: PinEntity[] = [];
    let id = 0;
    
    // Standard Bowling Rack Layout (Inverted Triangle / Pyramid facing down)
    // Row 0 (Top/Furthest): 4 pins
    // Row 1: 3 pins
    // Row 2: 2 pins
    // Row 3 (Bottom/Closest): 1 pin
    const totalRows = 4;

    for (let row = 0; row < totalRows; row++) {
      // Row 0 has 4 pins, decreasing to 1 pin at Row 3
      const pinsInRow = 4 - row;
      
      const rowWidth = (pinsInRow - 1) * PIN_SPACING_X;
      // Center the row horizontally
      const startX = (CANVAS_WIDTH / 2) - (rowWidth / 2);
      
      // Calculate Y position
      const y = PIN_START_Y + (row * PIN_SPACING_Y);
      
      for (let p = 0; p < pinsInRow; p++) {
        pins.push({
          id: id++,
          position: {
            x: startX + (p * PIN_SPACING_X),
            y: y
          },
          velocity: { x: 0, y: 0 }, // Initialize velocity
          isDown: false,
          opacity: 1
        });
      }
    }
    return pins;
  };

  // --- Reset Logic ---
  useEffect(() => {
    gameState.current.pins = initPins();
    gameState.current.ball = { x: CANVAS_WIDTH / 2, y: CANVAS_HEIGHT - 60, vx: 0, vy: 0 };
    gameState.current.isRolling = false;
    drawFrame();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resetTrigger]);

  // --- Ball Position Update during Aiming ---
  useEffect(() => {
    if (phase === GamePhase.AIMING) {
      // Constrain aiming to be STRICTLY inside the red lines
      // We calculate available width for the ball center
      const safeMinX = PLAY_AREA_MIN_X + BALL_RADIUS + 2; // +2 padding
      const safeMaxX = PLAY_AREA_MAX_X - BALL_RADIUS - 2;
      const safeWidth = safeMaxX - safeMinX;

      gameState.current.ball.x = safeMinX + (ballStartXPercent / 100) * safeWidth;
      gameState.current.ball.y = CANVAS_HEIGHT - 90;
      gameState.current.ball.vx = 0;
      gameState.current.ball.vy = 0;
      drawFrame();
    }
  }, [phase, ballStartXPercent]);

  // --- Trigger Throw ---
  useEffect(() => {
    if (phase === GamePhase.ROLLING && throwParams && !gameState.current.isRolling) {
      const { power, angle } = throwParams;
      const rad = (angle - 90) * (Math.PI / 180); 
      
      gameState.current.ball.vx = Math.cos(rad) * power;
      gameState.current.ball.vy = Math.sin(rad) * power;
      gameState.current.isRolling = true;
      gameState.current.stoppedFrames = 0;
      
      cancelAnimationFrame(requestRef.current!);
      requestRef.current = requestAnimationFrame(gameLoop);
    }
  }, [phase, throwParams]);

  // --- Physics Helper: Resolve Collision ---
  const resolveCollision = (
    p1: { x: number, y: number, vx: number, vy: number, mass?: number },
    p2: { x: number, y: number, vx: number, vy: number, mass?: number },
    r1: number,
    r2: number
  ) => {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const dist = Math.sqrt(dx*dx + dy*dy);

    if (dist < r1 + r2) {
      const nx = dx / dist;
      const ny = dy / dist;
      
      // Relative velocity
      const dvx = p1.vx - p2.vx;
      const dvy = p1.vy - p2.vy;
      
      const velAlongNormal = dvx * nx + dvy * ny;

      // Only resolve if moving towards each other
      if (velAlongNormal > 0) {
        const m1 = p1.mass || 1;
        const m2 = p2.mass || 1;

        const j = -(1 + RESTITUTION) * velAlongNormal;
        const impulse = j / (1/m1 + 1/m2);
        
        // Apply to 1 (add impulse*n / m1)
        p1.vx += (impulse * nx) / m1;
        p1.vy += (impulse * ny) / m1;
        
        // Apply to 2 (subtract impulse*n / m2)
        p2.vx -= (impulse * nx) / m2;
        p2.vy -= (impulse * ny) / m2;

        // Positional correction to stop overlap (sinking)
        const percent = 0.5; // resolve overlap
        const overlap = (r1 + r2 - dist);
        if (overlap > 0) {
            const correction = (overlap / (1/m1 + 1/m2)) * percent;
            const cx = correction * nx;
            const cy = correction * ny;
            
            p1.x -= cx / m1;
            p1.y -= cy / m1;
            p2.x += cx / m2;
            p2.y += cy / m2;
        }

        return true; // Collision occurred
      }
    }
    return false;
  };


  // --- Physics & Render Loop ---
  const gameLoop = () => {
    updatePhysics();
    drawFrame();

    if (gameState.current.isRolling) {
      requestRef.current = requestAnimationFrame(gameLoop);
    } else {
      const downedPins = gameState.current.pins.filter(p => p.isDown).map(p => p.id);
      onRollingComplete(downedPins);
    }
  };

  const updatePhysics = () => {
    const state = gameState.current;
    const { ball, pins } = state;

    // 1. Move Ball
    ball.x += ball.vx;
    ball.y += ball.vy;

    // 2. Move Active Pins (Pins that have been hit)
    pins.forEach(pin => {
      if (pin.isDown) { // We use isDown to signify "active physics body"
        pin.position.x += pin.velocity.x;
        pin.position.y += pin.velocity.y;
        
        // Pin Friction
        pin.velocity.x *= 0.95; // Higher friction for pins than ball
        pin.velocity.y *= 0.95;

        // Pin Wall Bounds (Constrain to Red Lines)
        // Check Left Red Line
        if (pin.position.x - PIN_RADIUS < PLAY_AREA_MIN_X) {
            pin.position.x = PLAY_AREA_MIN_X + PIN_RADIUS;
            pin.velocity.x *= -0.5;
        }
        // Check Right Red Line
        if (pin.position.x + PIN_RADIUS > PLAY_AREA_MAX_X) {
            pin.position.x = PLAY_AREA_MAX_X - PIN_RADIUS;
            pin.velocity.x *= -0.5;
        }

        // Y bounds remain the same (Canvas limits)
        if (pin.position.y - PIN_RADIUS < 0) {
            pin.position.y = PIN_RADIUS;
            pin.velocity.y *= -0.5;
        }
        if (pin.position.y + PIN_RADIUS > CANVAS_HEIGHT) {
            pin.position.y = CANVAS_HEIGHT - PIN_RADIUS;
            pin.velocity.y *= -0.5;
        }
      }
    });

    // 3. Ball Wall Collisions (RED LINE BUMPERS)
    // Left Red Line
    if (ball.x - BALL_RADIUS < PLAY_AREA_MIN_X) {
      ball.x = PLAY_AREA_MIN_X + BALL_RADIUS;
      ball.vx = -ball.vx * BOUNCE_FACTOR; // Bounce
    }
    // Right Red Line
    if (ball.x + BALL_RADIUS > PLAY_AREA_MAX_X) {
      ball.x = PLAY_AREA_MAX_X - BALL_RADIUS;
      ball.vx = -ball.vx * BOUNCE_FACTOR; // Bounce
    }
    
    // Top Bounce
    if (ball.y - BALL_RADIUS < 0) {
      ball.y = BALL_RADIUS;
      ball.vy = -ball.vy * BOUNCE_FACTOR;
    }

    // 4. Ball Friction
    ball.vx *= FRICTION;
    ball.vy *= FRICTION;

    // 5. Ball vs Pins Collisions
    pins.forEach(pin => {
       const pWrapper = { 
           x: pin.position.x, 
           y: pin.position.y, 
           vx: pin.velocity.x, 
           vy: pin.velocity.y,
           mass: PIN_MASS 
       };
       const bWrapper = { ...ball, mass: BALL_MASS };

       if (resolveCollision(bWrapper, pWrapper, BALL_RADIUS, PIN_RADIUS)) {
           // Update state from wrappers
           ball.vx = bWrapper.vx;
           ball.vy = bWrapper.vy;
           ball.x = bWrapper.x;
           ball.y = bWrapper.y;

           pin.velocity.x = pWrapper.vx;
           pin.velocity.y = pWrapper.vy;
           pin.position.x = pWrapper.x;
           pin.position.y = pWrapper.y;
           
           pin.isDown = true; // Mark as hit
       }
    });

    // 6. Pin vs Pin Collisions (Domino Effect)
    for (let i = 0; i < pins.length; i++) {
        for (let j = i + 1; j < pins.length; j++) {
            const p1 = pins[i];
            const p2 = pins[j];

            // Optimization: If both are still and not down, skip
            if (!p1.isDown && !p2.isDown) continue;

            const p1Wrapper = { 
                x: p1.position.x, y: p1.position.y, 
                vx: p1.velocity.x, vy: p1.velocity.y, 
                mass: PIN_MASS 
            };
            const p2Wrapper = { 
                x: p2.position.x, y: p2.position.y, 
                vx: p2.velocity.x, vy: p2.velocity.y, 
                mass: PIN_MASS 
            };

            if (resolveCollision(p1Wrapper, p2Wrapper, PIN_RADIUS, PIN_RADIUS)) {
                 // Transfer velocities back
                 p1.velocity.x = p1Wrapper.vx;
                 p1.velocity.y = p1Wrapper.vy;
                 p1.position.x = p1Wrapper.x;
                 p1.position.y = p1Wrapper.y;

                 p2.velocity.x = p2Wrapper.vx;
                 p2.velocity.y = p2Wrapper.vy;
                 p2.position.x = p2Wrapper.x;
                 p2.position.y = p2Wrapper.y;

                 // If a moving pin hits a static one, the static one becomes "Down" (Active)
                 // Just check if velocity is significant
                 const v1 = Math.sqrt(p1.velocity.x**2 + p1.velocity.y**2);
                 const v2 = Math.sqrt(p2.velocity.x**2 + p2.velocity.y**2);
                 
                 if (v1 > 0.1) p1.isDown = true;
                 if (v2 > 0.1) p2.isDown = true;
                 if (p1.isDown && v2 > 0.1) p2.isDown = true;
                 if (p2.isDown && v1 > 0.1) p1.isDown = true;
            }
        }
    }

    // 7. Stop Condition
    const ballSpeed = Math.sqrt(ball.vx * ball.vx + ball.vy * ball.vy);
    
    // Check if any pins are still moving significantly
    let pinsMoving = false;
    for (const p of pins) {
        if (p.isDown) {
            const speed = Math.sqrt(p.velocity.x**2 + p.velocity.y**2);
            if (speed > 0.1) {
                pinsMoving = true;
                break;
            }
        }
    }

    if ((ballSpeed < 0.1 || ball.y < -50 || ball.y > CANVAS_HEIGHT + 10) && !pinsMoving) {
      state.stoppedFrames++;
    } else {
      state.stoppedFrames = 0;
    }

    if (state.stoppedFrames > 40) { // slightly longer wait to let pins settle
      state.isRolling = false;
    }
  };

  const drawFrame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw Lane
    ctx.fillStyle = LANE_COLOR;
    ctx.fillRect(20, 0, CANVAS_WIDTH - 40, CANVAS_HEIGHT); // Main lane
    
    // Draw Gutters
    ctx.fillStyle = GUTTER_COLOR;
    ctx.fillRect(0, 0, 20, CANVAS_HEIGHT); // Left
    ctx.fillRect(CANVAS_WIDTH - 20, 0, 20, CANVAS_HEIGHT); // Right

    // Draw Lane Markings
    ctx.fillStyle = 'rgba(0,0,0,0.1)';
    for (let i = 1; i < 6; i++) {
        ctx.beginPath();
        const x = 20 + (i * ((CANVAS_WIDTH - 40) / 6));
        ctx.moveTo(x, 400);
        ctx.lineTo(x - 5, 380);
        ctx.lineTo(x + 5, 380);
        ctx.fill();
    }

    // --- DRAW RED BUMPER LINES ---
    ctx.beginPath();
    ctx.moveTo(PLAY_AREA_MIN_X, 0);
    ctx.lineTo(PLAY_AREA_MIN_X, CANVAS_HEIGHT);
    ctx.moveTo(PLAY_AREA_MAX_X, 0);
    ctx.lineTo(PLAY_AREA_MAX_X, CANVAS_HEIGHT);
    ctx.strokeStyle = '#ef4444'; // Red-500
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.stroke();

    // Draw Pins
    gameState.current.pins.forEach(pin => {
      // Draw shadow
      ctx.beginPath();
      ctx.ellipse(pin.position.x + 1, pin.position.y + 1, PIN_RADIUS, PIN_RADIUS * 0.8, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.fill();

      if (pin.isDown) {
        // Draw hit/moving pin
        ctx.beginPath();
        ctx.arc(pin.position.x, pin.position.y, PIN_RADIUS, 0, Math.PI * 2);
        ctx.fillStyle = '#eee'; // slightly darker
        ctx.fill();
        ctx.strokeStyle = '#999';
        ctx.stroke();
      } else {
        // Draw standing pin
        ctx.beginPath();
        ctx.arc(pin.position.x, pin.position.y, PIN_RADIUS, 0, Math.PI * 2);
        ctx.fillStyle = 'white';
        ctx.fill();
        // Red ring
        ctx.strokeStyle = 'red';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.lineWidth = 1;
      }
    });

    // Draw Ball
    const { x, y } = gameState.current.ball;
    // Shadow
    ctx.beginPath();
    ctx.ellipse(x + 2, y + 2, BALL_RADIUS, BALL_RADIUS * 0.8, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.fill();

    // Ball Body
    ctx.beginPath();
    ctx.arc(x, y, BALL_RADIUS, 0, Math.PI * 2);
    const gradient = ctx.createRadialGradient(x - 3, y - 3, 2, x, y, BALL_RADIUS);
    gradient.addColorStop(0, '#444');
    gradient.addColorStop(1, '#000');
    ctx.fillStyle = gradient;
    ctx.fill();
    
    // Finger holes
    ctx.fillStyle = '#111';
    ctx.beginPath();
    ctx.arc(x + 3, y - 3, 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(x + 5, y, 2, 0, Math.PI * 2);
    ctx.fill();
  };

  // Initial draw
  useEffect(() => {
    gameState.current.pins = initPins();
    requestAnimationFrame(drawFrame);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="relative rounded-lg overflow-hidden shadow-2xl border-4 border-slate-800">
      <canvas
        ref={canvasRef}
        width={CANVAS_WIDTH}
        height={CANVAS_HEIGHT}
        className="block bg-slate-900"
        style={{ width: '100%', maxWidth: '400px', height: 'auto' }}
      />
    </div>
  );
};

export default BowlingLane;